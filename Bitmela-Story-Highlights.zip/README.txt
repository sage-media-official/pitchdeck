BITMELA · INSTAGRAM STORY HIGHLIGHTS
1080x1920 PNG. Brand fonts (Bricolage Grotesque / IBM Plex Mono / Newsreader), brand colours, pattern strips, tickets, receipts, pixel squares.
All copy is taken from thebitmela.com (tickets, FAQ, schedule, speakers, what-to-expect).

00 Highlight covers (8)  — upload as the highlight cover; IG crops the centre circle.
01 Tickets (6)     02 Speakers (20)    03 The Mela (9)    04 Roast (5)
05 Schedule (7)    06 FAQ (10)         07 Partners (4)    08 BTS (6)

ADD IN THE INSTAGRAM APP (space is left for these):
- 01-06, 02-20: link sticker -> thebitmela.com (tickets / speakers)
- 04-04, 06-10: question sticker
- 04-02: when the comedian is confirmed, I swap "Comedian reveal soon" for the name (brief says Ashish Solanki; the site still says TBA)

NEED HI-RES EXPORTS FROM FIGMA (these were cropped from a screenshot and upscaled, so they look soft):
Spin the wheel, Ring toss, Live Jenga, Human slots, Roll the number, Choose your own money, Money swap, HODL,
Cotton candy, Popcorn, Tea on wheels, Tea Adda (board), Jaipur juttis, Shop merch, DIY station, Cakes gala,
Photo booth, Photo op, Help desk, Entry arch, Standees.
Also: team photos of Anuja, Palash, Santosh (the site only has 120px versions) + their roles for 08-02.

CHECK BEFORE POSTING:
- 01-05 / 06-08: transfers close 20 October.
- Techeye discount code is not on the site, so it isn't on a story. Send it and I'll add a card.
